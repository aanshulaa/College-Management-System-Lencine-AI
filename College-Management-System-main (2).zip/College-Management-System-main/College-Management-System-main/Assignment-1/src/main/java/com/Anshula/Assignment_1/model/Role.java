package com.santosh.Assignment_1.model;

public enum Role {
    STUDENT,
    FACULTY_MEMBER,
    ADMINISTRATOR;
}
